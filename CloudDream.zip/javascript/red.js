let funcionario = document.querySelector('#funcionario')

let empresa = document.querySelector('#empresa')

let investidor = document.querySelector('#investidor')

let ong = document.querySelector('#ong')

let botao = document.querySelector('#next')

redirecionar = () => {
    if(funcionario.checked){
        location.href = "/cadastro/cad-func.html"
        return;
    }

    if(empresa.checked){
        location.href = "/cadastro/cad-empre.html"
        return;
    }

    if(investidor.checked){
        location.href = "/cadastro/cad-invest.html"
        return;
    }

    if(ong.checked){
        location.href = "/cadastro/cad-ong.html"
        return;
    }

    alert("Escolha uma das opções");
}


botao.onclick = redirecionar